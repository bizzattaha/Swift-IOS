import UIKit

class Araba {
    var renk:String? //Sonradan Değer atıncağını gösterir !
    var hız:Int?
    var calisiyorMu:Bool? // bool True mu False mı olduğuu belirtir Daha sonradan tabi
    
    func hızlan(kacKm:Int){
        hız!+=kacKm
    }
    
    init(renk:String?,hız:Int?,calisiyorMu:Bool?) {
        self.renk = renk
        self.hız = hız
        self.calisiyorMu = calisiyorMu
    }
//    bu init func çalıştırıldığında otomatik initte çalışır.
//  self : bulunduğu sınıfı temsil eder.
    
    func BilgiAl() { // fonksiyon classa eklenmeli!! Çağırmasıda dışarda olucak. üsten aşa doğru okuyor kodları! side effect clasın değişkenleri değiştirmeye denir.
        print("---------------------")
        print("Renk : \(renk!)")
        print("Hız : \(hız!)")
        print("Çalışıyor mu ? : \(calisiyorMu!)")
        print("---------------------")
        
    }
}
var bmw = Araba(renk: "Kırmızı", hız: 5, calisiyorMu: true)
//bmw.renk = "Kırmızı"
//bmw.hız = 100
//bmw.calisiyorMu = true
//bmw.hızlan(kacKm: 50)
//bmw.BilgiAl()

//var mercedes = Araba()
//mercedes.renk = "mavi"
//mercedes.hız = 150
//mercedes.calisiyorMu = true
//mercedes.BilgiAl()

print("---------------------")
print("Renk : \(bmw.renk!)")
print("Hız : \(bmw.hız!)")
print("Çalışıyor mu ? : \(bmw.calisiyorMu!)")
print("---------------------")

//Class, referans tipi ortak bir değer yürütür
//struct iki değeri yürütür.

