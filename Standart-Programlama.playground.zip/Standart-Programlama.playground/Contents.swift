import UIKit

// Karşılaştırma Öperatörleri
//  || or iki koşulda sağlanıyorsa
// && And demek
// ! not tersine döndürür
// İf else tanımları tamamlandı
// switch içindeki kıyasalma yapar

var gun = 3
switch gun {
    case 1: print("Pazartesi")
    case 2: print("Salı")
    case 3: print("Çarşamba")
    case 4: print("Perşembe")
    case 5: print("Cuma")
    case 6: print("Cumartesi")
    case 7: print("Pazar")
    default: print("Böyle gün yok") // Default kullanmak zorunlu!
}

for x in 1...3 { // range kısmı 1 ile 3 arasında
    print("Döngü: \(x)")
}

for a in stride(from: 0, through: 20, by: 5) {
    print("Döngü 2: \(a)")
}
