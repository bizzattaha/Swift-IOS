import UIKit

var mesaj = "Merhaba"

var str:String? // ? nil tekabül ediyor

str = "Merhaba"

if str != nil {
    print(str!)//! unwrap yapmasını sağlar Oprtimal yazısını siler!
}else {
    print("Str Nil Değer İçeriyor.")
}

// Optional binding
if let temp = str {
    print(temp) // otomatik unwarp olmuş oluyor!
}else {
    print("Str Nil Değer İçeriyor.")
}
