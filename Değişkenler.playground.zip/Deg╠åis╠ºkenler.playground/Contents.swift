import UIKit

var greeting = "Hello, playground"
var rakam = 10
print(greeting)
if rakam > 100{
    print("Yüzden Büyük")
}
else{
    print("Yüzden küçük")
}

var OyuncuAdı = "Ahmad"
var OyuncuSoyismi = "Muhammed"
var Oyuncununparası = 12313

print("Oyuncu Adı  \(OyuncuAdı) ")

var OyuncuGrubu:String = "GS"


//Constant - Sabitler
//Kotlin -- val , java - final , dart - const
//Swify - let ,, let => sabit, güvenli ve daha hızlı swiftee

let numara = 100
print(numara)

// Tür Dönüşüleri int, float , double ,string

var i = 42
var d = 56.78

var sonuc1 = Double(i)
var sonuc2 = Int(d)
var sonuc3 = Float(d)
var sonuc4 = String(d)

print(sonuc3)

//Metinden Sayısala Dönüştürme
var yazi = "34"

let sonuc5 = Int(yazi)

print(sonuc5)
//Expression implicitly coerced from 'Int?' to 'Any' Hata alınır kontrol etmesi gerektiğini söyler.

if let sonuc6 = Int(yazi){
    print(sonuc6)
}else{
    print("hatalı")
}
